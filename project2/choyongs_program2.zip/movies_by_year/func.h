#ifndef __FUNC_H__
#define __FUNC_H__

#include <stdio.h>
#include "movie.h"

void print_sub_menu();
void make_dir(char* file_name);
void sub_func1();
void sub_func2();
void func1();

#endif