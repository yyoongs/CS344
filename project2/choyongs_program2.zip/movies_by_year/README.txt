<How to compile my code>

1. 
compile : gcc --std=gnu99 -o movies_by_year movie.c func.c main.c

run program : ./movies_by_year

2.
make directory name as movies_by_year
unzip choyongs_program2.zip in to movies_by_year directory
compile : make 
(makefile makes execute file name same as the directory name)

run program : ./movies_by_year
