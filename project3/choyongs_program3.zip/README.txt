<How to compile my code>

compile : gcc --std=gnu99 -o smallsh main.c
