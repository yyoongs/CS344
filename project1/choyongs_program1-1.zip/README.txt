<How to compile my code>

1. 
compile : gcc --std=gnu99 -o movies movie.c func.c main.c

run program : ./movies movies_sample_1.csv

2.
make directory name as movies
unzip choyongs_program1.zip in to movies directory
compile : make 
(makefile makes execute file name same as the directory name)

run program : ./movies movies_sample_1.csv
