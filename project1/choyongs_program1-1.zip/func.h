#ifndef __FUNC_H__
#define __FUNC_H__

#include <stdio.h>
#include "movie.h"

void func1(struct movie *list);
void func2(struct movie *list, int movie_count);
void func3(struct movie *list);

#endif